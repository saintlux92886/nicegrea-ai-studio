# NiceGrea AI Studio — Design Department MVP

A responsive Next.js starter for NiceGrea's AI Design Studio. It generates a design direction with a concept title, color palette, typography recommendations, art direction, logo concepts, an image-generation prompt, and UI notes. It also generates an actual PNG image through Vercel AI Gateway using `openai/gpt-image-2`.

## What works

- Responsive design studio UI
- Example briefs and style/deliverable selectors
- Server-side AI text generation through Vercel AI Gateway
- Structured design brief results and copy-to-clipboard
- API key remains server-side; it is not bundled into browser code
- Helpful error state if the key is missing or generation fails
- Actual AI image generation through `generateImage` and `openai/gpt-image-2`
- Generated image preview and Download PNG action
- Generated image is returned to the browser; this MVP does not persist it to a customer account

## Requirements

- Node.js 22 or later recommended for the current AI SDK
- A Vercel account
- An AI Gateway API key with model access/billing enabled

## Run locally

1. Install Node.js on a computer, then open this project folder in a terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your private key to `.env.local`:
   `AI_GATEWAY_API_KEY=your_private_key`
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

Never commit `.env.local`, and never put the key in a variable prefixed with `NEXT_PUBLIC_`.

## Deploy to Vercel

1. Put this project in a Git repository you control (GitHub is the usual beginner-friendly path).
2. In Vercel, choose **Add New → Project**, import the repository, and deploy using the default Next.js settings.
3. Open the Vercel project → **Settings → Environment Variables**.
4. Add `AI_GATEWAY_API_KEY` for Preview and Production (and Development if needed). Paste the key directly into Vercel; do not share it in chat or code.
5. Redeploy after adding the environment variable.
6. Test the Design Studio from the deployed URL.
7. Add `nicegrea.com` under **Settings → Domains** and follow the DNS instructions from Vercel/the domain registrar.

## AI model notes

- Design-brief text generation uses `openai/gpt-6-astra` through AI Gateway. Availability depends on your team and model access; if it is unavailable, replace the model string in `app/api/design/route.ts` with a current text model available to your team.
- Image generation uses `openai/gpt-image-2` in `app/api/image/route.ts`, following the AI Gateway image-generation quickstart. Confirm the model is available to your team and that you have sufficient AI Gateway credits.
- Both endpoints keep the AI Gateway key on the server. Never use a `NEXT_PUBLIC_` prefix for the key.

## Before charging customers

This is an MVP, not a complete multi-tenant SaaS yet. Before launch, add authentication, per-user project storage, rate limits/quotas, cost controls, abuse protection, privacy/terms pages, and monitoring. This is still an MVP, not a complete multi-tenant SaaS. Before launch, add authentication, per-user project storage, rate limits/quotas, cost controls, abuse protection, privacy/terms pages, and monitoring. Image generation currently previews the generated PNG in the browser and lets the user download it; it does not permanently save images to an account or object storage.
