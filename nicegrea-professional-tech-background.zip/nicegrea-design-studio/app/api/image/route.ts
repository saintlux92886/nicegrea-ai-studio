import { generateImage } from "ai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  try {
    if (!process.env.AI_GATEWAY_API_KEY) {
      return NextResponse.json(
        { error: "AI image generation is not connected yet. Add AI_GATEWAY_API_KEY in your local environment or Vercel project settings." },
        { status: 503 }
      );
    }

    const body = await request.json();
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";

    if (prompt.length < 8 || prompt.length > 4000) {
      return NextResponse.json(
        { error: "Please enter an image prompt between 8 and 4,000 characters." },
        { status: 400 }
      );
    }

    const { images } = await generateImage({
      model: "openai/gpt-image-2",
      prompt
    });

    const firstImage = images[0];
    if (!firstImage?.uint8Array?.byteLength) {
      return NextResponse.json(
        { error: "The image model returned no image. Please try a different prompt." },
        { status: 502 }
      );
    }

    return new Response(Buffer.from(firstImage.uint8Array), {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Content-Disposition": 'inline; filename="nicegrea-design.png"',
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff"
      }
    });
  } catch (error) {
    console.error("NiceGrea image generation error:", error);
    return NextResponse.json(
      { error: "We couldn't generate that image. Check AI Gateway access, credits, and model availability, then try again." },
      { status: 500 }
    );
  }
}
