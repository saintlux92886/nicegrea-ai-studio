import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NiceGrea Design Studio",
  description: "AI-powered brand, visual, and interface design workspace by NiceGrea."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
