 "use client";

import { FormEvent, useEffect, useState } from "react";

type DesignResult = {
  title: string;
  summary: string;
  palette: { name: string; hex: string; use: string }[];
  typography: string[];
  direction: string[];
  logoConcepts: string[];
  imagePrompt: string;
  uiNotes: string[];
};

const examples = [
  "A premium skincare brand for young professionals",
  "A modern fintech dashboard for small businesses",
  "A bold streetwear label with African-inspired patterns"
];

export default function Home() {
  const [brief, setBrief] = useState("");
  const [style, setStyle] = useState("Premium & minimal");
  const [deliverable, setDeliverable] = useState("Complete design direction");
  const [result, setResult] = useState<DesignResult | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [imagePrompt, setImagePrompt] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [imageLoading, setImageLoading] = useState(false);
  const [imageError, setImageError] = useState("");

  useEffect(() => {
    return () => {
      if (imageUrl) URL.revokeObjectURL(imageUrl);
    };
  }, [imageUrl]);

  async function createDesign(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setResult(null);
    setLoading(true);
    try {
      const response = await fetch("/api/design", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brief, style, deliverable })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Design generation failed.");
      setResult(data.result);
      setImagePrompt(data.result.imagePrompt || "");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  async function createImage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setImageError("");
    setImageLoading(true);
    try {
      const response = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: imagePrompt })
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || "Image generation failed. Please try again.");
      }
      const blob = await response.blob();
      const nextUrl = URL.createObjectURL(blob);
      setImageUrl(nextUrl);
    } catch (e) {
      setImageError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
    } finally {
      setImageLoading(false);
    }
  }

  function copyResult() {
    if (!result) return;
    const text = [
      result.title, result.summary, "",
      "COLOR PALETTE",
      ...result.palette.map((c) => `${c.name}: ${c.hex} — ${c.use}`),
      "", "TYPOGRAPHY", ...result.typography,
      "", "ART DIRECTION", ...result.direction,
      "", "LOGO CONCEPTS", ...result.logoConcepts,
      "", "IMAGE GENERATION PROMPT", result.imagePrompt,
      "", "UI NOTES", ...result.uiNotes
    ].join("\\n");
    navigator.clipboard.writeText(text).catch(() => setError("Clipboard access was blocked. You can select and copy the result manually."));
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <a className="brand" href="#" aria-label="NiceGrea home">
          <span className="brand-mark">N<span>✦</span></span>
          <span><strong>NiceGrea</strong><small>AI CREATIVE STUDIO</small></span>
        </a>
        <div className="side-label">WORKSPACE</div>
        <div className="nav-item active"><span>◈</span> Design Studio <span className="nav-dot" /></div>
        <div className="nav-item muted"><span>▧</span> Brand identity</div>
        <div className="nav-item muted"><span>▦</span> UI / UX concepts</div>
        <div className="nav-item muted"><span>✳</span> Creative prompts</div>
        <div className="side-bottom">
          <div className="status"><span className="green-dot" /> Design engine ready</div>
          <p>Make ideas tangible.</p>
          <small>NiceGrea.com · Founder workspace</small>
        </div>
      </aside>

      <section className="main">
        <header className="topbar">
          <div><span className="crumb">Studio</span><span className="slash">/</span><strong>Design Department</strong></div>
          <span className="pill"><span className="green-dot" /> AI workspace</span>
        </header>

        <section className="hero">
          <div className="eyebrow"><span className="spark">✦</span> NICEGREA DESIGN DEPARTMENT</div>
          <h1>Turn your ideas into<br /><em>beautiful direction.</em></h1>
          <p>Build a brand identity, shape a digital product, and create a clear visual system — with an AI design partner.</p>
        </section>

        <div className="workspace">
          <form className="brief-card" onSubmit={createDesign}>
            <div className="card-heading"><div><span className="step">01</span><h2>Describe your vision</h2></div><span className="mini-tag">DESIGN BRIEF</span></div>
            <label htmlFor="brief">What are we designing?</label>
            <textarea id="brief" value={brief} onChange={(e) => setBrief(e.target.value)} required minLength={8} maxLength={1800} placeholder="Tell us about the brand, product, audience, and feeling you want to create..." />
            <div className="examples"><span>TRY AN IDEA</span>{examples.map((item) => <button type="button" key={item} onClick={() => setBrief(item)}>{item}</button>)}</div>
            <div className="fields">
              <div><label htmlFor="style">Visual style</label><select id="style" value={style} onChange={(e) => setStyle(e.target.value)}><option>Premium & minimal</option><option>Bold & expressive</option><option>Futuristic technology</option><option>Warm & organic</option><option>Playful & colorful</option><option>Editorial & elegant</option></select></div>
              <div><label htmlFor="deliverable">Deliverable</label><select id="deliverable" value={deliverable} onChange={(e) => setDeliverable(e.target.value)}><option>Complete design direction</option><option>Brand identity</option><option>Website or app UI/UX</option><option>Social media campaign</option><option>Product packaging</option></select></div>
            </div>
            <button className="generate" type="submit" disabled={loading || brief.trim().length < 8}>{loading ? <><span className="spinner" /> Creating design direction…</> : <>✦ Generate design direction <span>↗</span></>}</button>
            <p className="privacy-note">AI output is a starting concept. Review it before using it commercially.</p>
            {error && <div className="error" role="alert">{error}</div>}
          </form>

          <section className="results">
            <div className="card-heading result-heading"><div><span className="step">02</span><h2>Your design board</h2></div>{result && <button className="copy" onClick={copyResult} type="button">Copy brief ↗</button>}</div>
            {!result && !loading && <div className="empty-board">
              <div className="orb"><span>✦</span></div>
              <h3>Your next big idea starts here.</h3>
              <p>Submit a design brief and your board will include a visual direction, color palette, typography, logo concepts, and a ready-to-use image prompt.</p>
              <div className="preview-chips"><span>COLOR SYSTEM</span><span>ART DIRECTION</span><span>LOGO IDEAS</span></div>
            </div>}
            {loading && <div className="loading-board"><div className="loading-art" /><div className="skeleton line" /><div className="skeleton short" /><div className="skeleton line" /><div className="skeleton short" /><p>Thinking through the visual system…</p></div>}
            {result && <div className="design-output">
              <div className="output-title"><span className="mini-tag">DESIGN CONCEPT</span><h3>{result.title}</h3><p>{result.summary}</p></div>
              <h4>Color system</h4>
              <div className="swatches">{result.palette.map((c) => <div className="swatch" key={c.hex}><div className="swatch-color" style={{ backgroundColor: /^#[0-9A-Fa-f]{6}$/.test(c.hex) ? c.hex : "#9CA3AF" }} /><strong>{c.name}</strong><code>{c.hex}</code><small>{c.use}</small></div>)}</div>
              <h4>Typography direction</h4><ul>{result.typography.map((x, i) => <li key={i}>{x}</li>)}</ul>
              <h4>Art direction</h4><ul>{result.direction.map((x, i) => <li key={i}>{x}</li>)}</ul>
              <h4>Logo concepts</h4><ul>{result.logoConcepts.map((x, i) => <li key={i}>{x}</li>)}</ul>
              <h4>Image-generation prompt</h4><div className="prompt-box">{result.imagePrompt}</div>
              <h4>UI / experience notes</h4><ul>{result.uiNotes.map((x, i) => <li key={i}>{x}</li>)}</ul>
              <button className="generate secondary" type="button" onClick={copyResult}>Copy full design brief ↗</button>
            </div>}
          </section>
        </div>
        <section className="image-studio">
          <div className="card-heading image-heading"><div><span className="step">03</span><h2>AI Image Generator</h2></div><span className="mini-tag">POWERED BY AI GATEWAY</span></div>
          <p className="image-intro">Turn a creative prompt into an actual image. You can use the prompt from your design board or write your own.</p>
          <form onSubmit={createImage}>
            <label className="image-label" htmlFor="image-prompt">Describe the image you want</label>
            <textarea id="image-prompt" className="image-prompt-input" value={imagePrompt} onChange={(e) => setImagePrompt(e.target.value)} required minLength={8} maxLength={4000} placeholder="Example: A premium product campaign with soft studio lighting, elegant composition, and a modern editorial feel..." />
            <div className="image-actions">
              <button className="generate image-generate" type="submit" disabled={imageLoading || imagePrompt.trim().length < 8}>{imageLoading ? <><span className="spinner" /> Generating image…</> : <>✦ Generate actual image <span>↗</span></>}</button>
              {result && <button className="copy use-design-prompt" type="button" onClick={() => { setImagePrompt(result.imagePrompt); setImageError(""); }}>Use design-board prompt</button>}
            </div>
          </form>
          {imageError && <div className="error" role="alert">{imageError}</div>}
          {imageLoading && <div className="image-placeholder"><div className="spinner" /> Creating your image. This can take a little while…</div>}
          {imageUrl && !imageLoading && <div className="generated-image-card"><img src={imageUrl} alt="Image generated by NiceGrea AI Studio" /><div className="generated-image-footer"><div><strong>Your generated image</strong><small>Review the result before commercial use.</small></div><a href={imageUrl} download="nicegrea-design.png" className="download-image">Download PNG ↗</a></div></div>}
          <p className="privacy-note">Image generation uses AI Gateway credits and model availability. Generated images are returned to this browser for preview; this MVP does not permanently save them to a customer account.</p>
        </section>
        <footer><span>© {new Date().getFullYear()} NiceGrea AI Studio</span><span>DESIGNED FOR IDEAS THAT MOVE THE WORLD</span></footer>
      </section>
    </main>
  );
}
